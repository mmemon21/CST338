public interface Ability {

}
