public interface Attack implements Ability {
    Integer attack(Monster){

    }
}
